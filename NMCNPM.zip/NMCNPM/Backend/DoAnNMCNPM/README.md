Sửa file application.propertites 
nameDatabase: database chứa dữ liệu



spring.datasource.username={{tên đăng nhập vào database}}
spring.datasource.password={{pass đăng nhập vào database}}

