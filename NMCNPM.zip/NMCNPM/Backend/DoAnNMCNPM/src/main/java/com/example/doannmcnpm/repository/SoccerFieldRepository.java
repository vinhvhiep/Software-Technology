package com.example.doannmcnpm.repository;

import com.example.doannmcnpm.model.SoccerField;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SoccerFieldRepository extends JpaRepository<SoccerField, Integer> {
}
