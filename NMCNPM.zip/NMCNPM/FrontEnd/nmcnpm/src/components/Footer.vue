<template>
  <footer>
    <div class="container pt-5">
      <div class="row">
        <div class="col-md-3 col-6">
          <ul style="list-style-type: none">
            <li class="text-light font-weigh-bold pb-2">Get to know us</li>
            <li>
              <a class="footer-link font-weight-light" href="#"> About us </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#">
                Android App
              </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#"> Ios App </a>
            </li>
          </ul>
        </div>
        <div class="col-md-3 col-6">
          <ul style="list-style-type: none">
            <li class="text-light font-weigh-bold pb-2">Connect with us</li>
            <li>
              <a class="footer-link font-weight-light" href="#"> About us </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#">
                Android App
              </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#"> Ios App </a>
            </li>
          </ul>
        </div>
        <div class="col-md-3 col-6">
          <ul style="list-style-type: none">
            <li class="text-light font-weigh-bold pb-2">Make Money with us</li>
            <li>
              <a class="footer-link font-weight-light" href="#"> About us </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#">
                Android App
              </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#"> Ios App </a>
            </li>
          </ul>
        </div>
        <div class="col-md-3 col-6">
          <ul style="list-style-type: none">
            <li class="text-light font-weigh-bold pb-2">Let us help you</li>
            <li>
              <a class="footer-link font-weight-light" href="#"> About us </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#">
                Android App
              </a>
            </li>
            <li>
              <a class="footer-link font-weight-light" href="#"> Ios App </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer__logo text-center">
      <img class="footer__logo--img" src="../assets/vtvlogo.png" alt="logo" />
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style>
footer {
  margin-top: 100px;
  background-color: #232f3e;
  font-size: 16px;
}
a {
  text-decoration: none;
}
.footer-link {
  color: #ddd;
}
li {
  padding-bottom: 10px;
}
.footer__logo--img {
  width: 100px;
}
</style>
