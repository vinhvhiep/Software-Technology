<template>
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h4>Our SoccerFlied</h4>
        <router-link :to="{ name: 'AddSoccerFlied' }" style="float: right">
          <button class="btn">Add SoccerFlied</button>
        </router-link>
      </div>
    </div>
    <div class="row">
      <!--            display all the products in productbox component-->
      <div
        v-for="soccerField of soccerFields"
        :key="soccerField.id"
        class="col-md-6 col-xl-4 col-12 pt-3 d-flex"
      >
        <SoccerFieldBox :soccerField="soccerField" />
      </div>
    </div>
  </div>
</template>
<script>
import SoccerFieldBox from "../../components/SoccerFieldBox";
export default {
  components: { SoccerFieldBox },
  props: ["soccerFields"],
  mounted() {},
};
</script>
